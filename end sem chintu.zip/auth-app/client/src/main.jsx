import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import { AuthProvider } from "./AuthContext.jsx";
import "./styles.css";

createRoot(document.getElementById("root")).render(
  <AuthProvider><App /></AuthProvider>
);
